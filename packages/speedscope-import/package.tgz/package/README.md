# @flamedeck/import

Speedscope import utilities for parsing various performance profile formats. This package provides the core functionality for importing and converting performance profiles from different sources into the Speedscope format.

## Installation

```bash
npm install @flamedeck/import
```

## Usage

```typescript
import { importFromBufferAsync } from '@flamedeck/import';

// Import a profile from a buffer
const profile = await importFromBufferAsync(buffer, 'profile.cpuprofile');

// The profile is now in Speedscope format and ready for analysis
```

## Supported Formats

This package supports all the same formats as [Speedscope](https://github.com/jlfwong/speedscope):

- **Chrome DevTools CPU Profiles** (`.cpuprofile`)
- **Firefox Profiler** format
- **Node.js profiles**
- **pprof** format (Go, C++, etc.)
- **Stackprof** (Ruby)
- **Instruments** (macOS)
- **Perf** (Linux)
- And many more...

## API

### `importFromBufferAsync(buffer: ArrayBuffer, fileName: string): Promise<Profile>`

Imports a performance profile from a buffer.

- `buffer`: The profile data as an ArrayBuffer
- `fileName`: The original filename (used for format detection)
- Returns: A Promise that resolves to a Speedscope-compatible profile object

## Related Packages

- [`@flamedeck/speedscope-core`](https://www.npmjs.com/package/@flamedeck/speedscope-core) - Core Speedscope data structures
- [`@flamedeck/flamechart-mcp`](https://www.npmjs.com/package/@flamedeck/flamechart-mcp) - MCP server for flamegraph analysis
- [`@flamedeck/upload`](https://www.npmjs.com/package/@flamedeck/upload) - Upload traces to FlameDeck

## License

ISC

## Development

### Generating Protobuf Code

This package includes importers for pprof (protobuf) formatted profiles. The TypeScript code for handling these protobuf definitions is generated from a `.proto` schema file.

If you modify `packages/speedscope-import/src/speedscope-import/profile.proto`, you will need to regenerate the corresponding TypeScript file (`profile.proto.ts`) using the following command from the workspace root:

```bash
npx pbjs --ts packages/speedscope-import/src/speedscope-import/profile.proto.ts packages/speedscope-import/src/speedscope-import/profile.proto
```

This command uses `pbjs` (from `protobufjs-cli`) to convert the `.proto` file directly into a TypeScript module that includes both the runtime logic and type definitions for the protobuf messages.

**Prerequisites:**

- Ensure `protobufjs-cli` is available. You can install it globally (`npm install -g protobufjs-cli`) or add it as a dev dependency to the workspace root and run via `npx pbjs ...`.
